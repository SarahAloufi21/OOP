/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


public class SaudiArabianAirlines extends AirPlaneCompany {

    public SaudiArabianAirlines() {
        CompName = "Saudi Arabian Airlines";
        Symbol = "SV";
        AllFlights++;
    }

    public void CompInfo() {
        Window w = new Window(" Saudi Company", "C:\\Users\\msms1\\OneDrive\\Documents\\NetBeansProjects\\OOP\\src\\main\\java\\msg1541330102-31198 (1).jpg");
        w.setVisible(true);
    }
}
