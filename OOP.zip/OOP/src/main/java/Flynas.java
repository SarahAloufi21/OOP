/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


public class Flynas extends AirPlaneCompany {

    public Flynas() {
        CompName = "Flynas";
        Symbol = "XY";
    }

    public void CompInfo() {
        Window w = new Window(" Flynas Company", "C:\\Users\\msms1\\OneDrive\\Documents\\NetBeansProjects\\OOP\\src\\main\\java\\msg1541330102-31199 (1).jpg");
        w.setVisible(true);
    }

}
